# CampX AI — Smart Campus Assistant

A modern Gen-Z SaaS-style frontend for an AI Campus Assistant.

## Features

- Responsive student dashboard
- Sidebar navigation
- Dark/light mode with localStorage
- AI assistant chat UI with demo responses
- Smart timetable
- Placement preparation dashboard
- Resume upload interface
- Exam preparation and resources
- Campus map interface
- Learning resources
- Progress analytics
- Interactive buttons, tasks, filters and toast notifications

## Run locally

Simply open `index.html` in a browser, or use VS Code Live Server.

## Backend roadmap

Connect the UI to:
- Node.js + Express
- MongoDB/MySQL
- Authentication
- AI API for the campus chatbot
- Resume parsing + AI scoring
- YouTube/resource APIs
- College timetable/database
- Real campus map API
