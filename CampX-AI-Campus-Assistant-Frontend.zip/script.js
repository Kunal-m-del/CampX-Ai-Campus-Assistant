const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

const pageNames = {
  dashboard:"Dashboard", assistant:"AI Assistant", schedule:"Smart Schedule",
  placement:"Placements", resume:"Resume Analyzer", exams:"Exam Prep",
  map:"Campus Map", resources:"Resources", progress:"Progress"
};

function showPage(id){
  $$(".page").forEach(p=>p.classList.remove("active"));
  const page = document.getElementById(id);
  if(page) page.classList.add("active");
  $$(".nav-item[data-section]").forEach(b=>b.classList.toggle("active", b.dataset.section===id));
  $("#pageTitle").textContent = pageNames[id] || id;
  window.scrollTo({top:0,behavior:"smooth"});
  $("#sidebar").classList.remove("open");
}

$$(".nav-item[data-section]").forEach(btn=>btn.addEventListener("click",()=>showPage(btn.dataset.section)));
$$("[data-go]").forEach(btn=>btn.addEventListener("click",()=>showPage(btn.dataset.go)));

$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));

const themeToggle=$("#themeToggle");
const savedTheme=localStorage.getItem("campx-theme");
if(savedTheme==="dark") document.body.classList.add("dark");
function updateThemeText(){themeToggle.innerHTML=document.body.classList.contains("dark")?"<span>☀</span> Light mode":"<span>☾</span> Dark mode"}
updateThemeText();
themeToggle.addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("campx-theme",document.body.classList.contains("dark")?"dark":"light");
  updateThemeText();
});

function toast(text="Saved successfully ✓"){
  const t=$("#toast"); t.textContent=text; t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),2200);
}

$("#notificationBtn").addEventListener("click",()=>toast("You have 3 new campus updates 🔔"));

const messages=$("#messages");
function addMessage(text,type){
  const wrap=document.createElement("div");
  wrap.className="message "+type;
  if(type==="bot") wrap.innerHTML=`<div class="bot-avatar">✦</div><div><p>${text}</p></div>`;
  else wrap.innerHTML=`<div><p>${text}</p></div>`;
  messages.appendChild(wrap); messages.scrollTop=messages.scrollHeight;
}
function aiReply(q){
  const s=q.toLowerCase();
  if(s.includes("schedule")) return "Your next sessions are Web Technologies at 11:00, Machine Learning at 14:00 and Placement Workshop at 16:00. 📅";
  if(s.includes("placement")||s.includes("dsa")) return "Start with 60–90 minutes of DSA daily, then aptitude and one mock interview each week. Your current placement readiness is 64%. 🚀";
  if(s.includes("resume")) return "Upload your PDF/DOC resume in Resume Analyzer. The frontend is ready for ATS keywords, impact statements and skill feedback.";
  if(s.includes("exam")||s.includes("notes")) return "For exams, prioritize Data Structures, Machine Learning and Web Technologies. I can help turn your syllabus into a day-by-day plan. 📚";
  if(s.includes("map")||s.includes("library")||s.includes("canteen")) return "Open Campus Map to find the Main Block, Library, Labs, Canteen and Auditorium. 📍";
  return "I can help with your schedule, exams, placement preparation, resume, campus navigation and learning resources. Try one of the smart prompts! ✦";
}
$("#chatForm").addEventListener("submit",e=>{
  e.preventDefault(); const input=$("#chatInput"); const q=input.value.trim(); if(!q)return;
  addMessage(q,"user"); input.value="";
  setTimeout(()=>addMessage(aiReply(q),"bot"),450);
});
$$(".suggestions button").forEach(b=>b.addEventListener("click",()=>{$("#chatInput").value=b.textContent;$("#chatForm").requestSubmit()}));
$$(".prompt").forEach(b=>b.addEventListener("click",()=>{$("#chatInput").value=b.dataset.prompt;$("#chatForm").requestSubmit()}));
$("#clearChat").addEventListener("click",()=>{messages.innerHTML=`<div class="message bot"><div class="bot-avatar">✦</div><div><p>Chat cleared. How can I help? 👋</p></div></div>`});

$("#resumeUpload").addEventListener("click",()=>$("#resumeFile").click());
$("#resumeFile").addEventListener("change",e=>{
  const file=e.target.files[0];
  if(file){$("#fileName").textContent=`Selected: ${file.name}`;toast("Resume selected ✓")}
});

$$(".map-point").forEach(btn=>btn.addEventListener("click",()=>{
  $$(".map-point").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
  $("#selectedPlace").textContent=btn.dataset.place;toast(`${btn.dataset.place} selected 📍`);
}));

$$(".mark-btn").forEach(btn=>btn.addEventListener("click",()=>{btn.textContent="✓ Done";btn.style.color="#15945e";toast("Task marked complete ✓")}));
$$(".task input").forEach(box=>box.addEventListener("change",()=>toast(box.checked?"Task completed ✓":"Task reopened")));
$("#addTask").addEventListener("click",()=>toast("Task creator ready — connect this button to your backend/database."));

$$(".filter").forEach(btn=>btn.addEventListener("click",()=>{$$(".filter").forEach(x=>x.classList.remove("active"));btn.classList.add("active");toast(`Showing ${btn.textContent} resources`)}));
$$(".week-tabs button").forEach(btn=>btn.addEventListener("click",()=>{$$(".week-tabs button").forEach(x=>x.classList.remove("active-day"));btn.classList.add("active-day");toast(`${btn.textContent} schedule loaded`)}));
